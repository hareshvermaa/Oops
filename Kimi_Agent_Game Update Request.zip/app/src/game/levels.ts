export type GadgetType='ramp'|'bounce'|'fan'|'spring'|'seesaw'|'domino';
export interface Gadget{id:string;type:GadgetType;x:number;y:number;angle:number}
export interface Obstacle{x:number;y:number;w:number;h:number;angle?:number;color?:string}
export interface Level{id:number;set:number;stage:number;title:string;difficulty:'MEDIUM'|'HARD'|'EXTREME'|'ULTRA';ball:{x:number;y:number};target:{x:number;y:number};obstacles:Obstacle[];available:Record<GadgetType,number>;solution:Omit<Gadget,'id'>[];par:number}
export const THEMES=[
['Candy Clouds','#ff70b7','#7c3aed','🍭'],['Frostberry Peaks','#66e0ff','#4263eb','❄️'],['Ember Orchard','#ff9f43','#e11d48','🔥'],['Jungle Jamboree','#65e68a','#087f5b','🌴'],['Moonlight Museum','#a68bfa','#312e81','🌙'],['Coral Carnival','#55e6d8','#087f8c','🐠'],['Clockwork Cove','#ffd166','#9c6644','⚙️'],['Neon Noodle City','#ff5c8a','#5f27cd','🍜'],['Haunted Honeywood','#b197fc','#44248a','🎃'],['Crystal Caverns','#8ce8ff','#6941c6','💎'],['Sunken Kingdom','#4dd4ac','#085f63','🏛️'],['Volcano Village','#ff7849','#8c2f39','🌋'],['Cloudberry Castle','#ffc8dd','#7667d9','🏰'],['Robo Rooftops','#7ee8fa','#364fc7','🤖'],['Pirate Pudding Bay','#ffd43b','#0b7285','🏴‍☠️'],['Aurora Acres','#94f0c1','#7048e8','🌌'],['Dino Dessert Land','#b2f2bb','#e8590c','🦕'],['Starlight Circus','#ff8fab','#7b2cbf','🎪'],['Ancient Cocoa Ruins','#e6b980','#6f4518','🗿'],['Rainbow Rift','#ffe066','#e64980','🌈']
] as const;
const names=['First Fluff','Twisty Turn','Pocket Rocket','Breezy Business','Domino Day','Seesaw Surprise','Double Trouble','Skyline Sprint','Tricky Treasure','Set Finale'];
const gadgetTypes:GadgetType[]=['ramp','bounce','fan','spring','seesaw','domino'];
export const LEVELS:Level[]=Array.from({length:200},(_,i)=>{const id=i+1,set=Math.floor(i/10),stage=i%10,variant=i%5;const diff=set<3?'MEDIUM':set<8?'HARD':set<14?'EXTREME':'ULTRA';const left=variant%2===0;const ball={x:left?110:610,y:105+(variant===3?45:0)};const target={x:left?590:130,y:820-(variant===4?100:0)};const obstacles:Obstacle[]=[
{x:360,y:365,w:390-(stage*8),h:28,angle:left?8:-8},
{x:left?515:205,y:600,w:250+(stage*4),h:26,angle:left?-10:10},
...(stage>4?[{x:360,y:760,w:150,h:24,angle:0}]:[]),
...(stage>7?[{x:360,y:205,w:110,h:22,angle:25}]:[])
];const type=gadgetTypes[variant];const second=gadgetTypes[(variant+1)%6];const solution:Omit<Gadget,'id'>[]=[{type,x:left?215:505,y:280,angle:left?25:155}];if(stage>1)solution.push({type:second,x:left?470:250,y:705,angle:second==='fan'?(left?0:180):(left?20:160)});
const available={ramp:0,bounce:0,fan:0,spring:0,seesaw:0,domino:0} as Record<GadgetType,number>;available[type]=1+(stage>6?1:0);available[second]=stage>1?1:0;if(id===1){available.ramp=2;available.bounce=0}if(id===2){available.ramp=1;available.bounce=1;available.fan=1}
return{id,set,stage,title:names[stage],difficulty:diff as Level['difficulty'],ball,target,obstacles,available,solution,par:12+stage*2};});
export const getLevel=(id:number)=>LEVELS[Math.max(0,Math.min(199,id-1))];
export const GADGETS:Record<GadgetType,{name:string;icon:string;color:string}>= {ramp:{name:'Ramp',icon:'📐',color:'#f59e0b'},bounce:{name:'Bounce',icon:'🟣',color:'#ec4899'},fan:{name:'Fan',icon:'🌬️',color:'#06b6d4'},spring:{name:'Spring',icon:'🌀',color:'#f97316'},seesaw:{name:'Seesaw',icon:'⚖️',color:'#10b981'},domino:{name:'Domino',icon:'🁡',color:'#8b5cf6'}};
